ushort 	macSSID        			= 0x1234;       
uint	llsSBOMin				= 5;
byte    llsVendorId				= 2;
byte    macExternalAntCfg		= 0;
byte    llsJitterMultiplier		= 40;
byte	llsCfg					= 1; 

//string  CertDir     			= @"\\spade.blackhawk-lab.itron.com\SecTool\ITRON METER FARM FOR COMMS 2 (S14)";	///< relative path to the security files;
string  CertDir     			= ScriptDir+@"\..\security";	
	
//css_using Itron.Mdapi.Dev500S.Classes;

//css_code _pib_ids.part.cs
//css_code _defs.part.cs

UInt64 MacAddr = ReadMacAddress();
ToLog("MAC = 0x{0:X16}\n", MacAddr);

/* Write PIBs */
DLLSetPib(DLL_PIB_ID_macUtcTime, 			0, BitConverter.GetBytes(Utils.GetUTC1970TimeStamp()));
DLLSetPib(DLL_PIB_ID_macSSID, 				0, BitConverter.GetBytes(macSSID));
DLLSetPib(DLL_PIB_ID_llsCfg, 				0, BitConverter.GetBytes(llsCfg));
DLLSetPib(DLL_PIB_ID_llsSBOMin, 			0, BitConverter.GetBytes(llsSBOMin));	
DLLSetPib(DLL_PIB_ID_llsVendorId, 			0, BitConverter.GetBytes(llsVendorId));	
DLLSetPib(DLL_PIB_ID_llsJitterMultiplier, 	0, BitConverter.GetBytes(llsJitterMultiplier));	
DLLSetPib(DLL_PIB_ID_macExternalAntCfg, 	0, BitConverter.GetBytes(macExternalAntCfg));	

/* Save To Flash */
DBI("0C",5000);   

//css_code _cert_inject.part.cs
//css_code _KeyInjector.part.cs
ToLog("\n\n********\n Script Complete!\n***********");   
