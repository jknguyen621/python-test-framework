
if( CertDir != null )
{
ToLog("{0}\n", Itron.Mdapi.Dev500S.Classes.SecToolCerts.LoadCerts(Api, CertDir, MacAddr.ToString("X16"))); 
}
else
	ToLog("Cert Injection not Requested.\n");
