ushort 	macSSID        			= 5556;       

byte	bactStarEnabled			= 1;
byte	bactMeshEnabled			= 1;
byte	bactPreferredTopology	= 0;
uint	bactLBOMinWindow		= 10;
uint    bactSBOMinWindow		= 10;

string	bactChannelMaskMesh		= "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffff";
string	bactChannelMaskStar		= "04040404040404040404040404040404040400040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404";

uint 	bactPhyPrintMask_0 		= 0x000000013;
uint 	bactPhyPrintMask_1		= 0x00000001;
uint 	macPrintMask     		= 0x00001E5F;

byte	efcLaEnabled			= 0;
byte	efcClientEnabled		= 0;
byte	efcRouterEnabled		= 1;
byte 	efcDWNMDuration 		= 10;	/* Discovery normal mode duration */
byte 	efcDWDuration 			= 1;	/* Duration of discovery window */
byte 	efcDWRepeatInterval 	= 20;	/* Repeat interval of discovery */
ushort 	efcFNBeaconInterval 	= 300;	/* FN Periodic Beacon Repeat interval */
byte 	efcEvalMinDur			= 5;	/*  EFC Minimum Link Eval duration in minutes */

//string  CertDir     			= @"\\spade.blackhawk-lab.itron.com\SecTool\ITRON METER FARM FOR COMMS 2 (S14)";	///< relative path to the security files;
string  CertDir     			= ScriptDir+@"\..\security";	
	
//css_using Itron.Mdapi.Dev500S.Classes;

//css_code _pib_ids.part.cs
//css_code _defs.part.cs

UInt64 MacAddr = ReadMacAddress();
ToLog("MAC = 0x{0:X16}\n", MacAddr);

/* Write PIBs */
DLLSetPib(DLL_PIB_ID_macUtcTime, 			0, BitConverter.GetBytes(Utils.GetUTC1970TimeStamp()));
DLLSetPib(DLL_PIB_ID_macSSID, 				0, BitConverter.GetBytes(macSSID));
DLLSetPib(DLL_PIB_ID_bactCfg, 				0, BitConverter.GetBytes(bactPreferredTopology * 4 + bactStarEnabled * 2 + bactMeshEnabled));
DLLSetPib(DLL_PIB_ID_efcCfg, 				0, BitConverter.GetBytes(efcLaEnabled + efcClientEnabled * 2 + efcRouterEnabled * 4));
DLLSetPib(DLL_PIB_ID_efcChanMask, 			0, "00000000000000FF".ToByteArr().Reverse().ToHexStr().ToByteArr());
DLLSetPib(DLL_PIB_ID_efcChanMask, 			1, "00000000000000FF".ToByteArr().Reverse().ToHexStr().ToByteArr());
DLLSetPib(DLL_PIB_ID_bactChannelMask, 		0, bactChannelMaskMesh.ToByteArr().Reverse().ToHexStr().ToByteArr());
DLLSetPib(DLL_PIB_ID_bactChannelMask, 		1, bactChannelMaskStar.ToByteArr().Reverse().ToHexStr().ToByteArr());
DLLSetPib(DLL_PIB_ID_bactLBOMinWindow, 		0, BitConverter.GetBytes(bactLBOMinWindow));	
DLLSetPib(DLL_PIB_ID_bactSBOMinWindow, 		0, BitConverter.GetBytes(bactSBOMinWindow));	
DLLSetPib(DLL_PIB_ID_efcDWNMDuration, 		0, BitConverter.GetBytes(efcDWNMDuration));		
DLLSetPib(DLL_PIB_ID_efcDWDuration, 		0, BitConverter.GetBytes(efcDWDuration));			
DLLSetPib(DLL_PIB_ID_efcDWRepeatInterval, 	0, BitConverter.GetBytes(efcDWRepeatInterval));	
DLLSetPib(DLL_PIB_ID_efcFNBeaconInterval, 	0, BitConverter.GetBytes(efcFNBeaconInterval));	
DLLSetPib(DLL_PIB_ID_efcEvalMinDur, 		0, BitConverter.GetBytes(efcEvalMinDur));

ToLog("Mesh ChMask: {0}\n", S500Utils.GetParamData(Api, DLL_PIB_ID_bactChannelMask, 0).Reverse().ToHexStr());
ToLog("Star ChMask: {0}\n", S500Utils.GetParamData(Api, DLL_PIB_ID_bactChannelMask, 1).Reverse().ToHexStr());

/* Save To Flash */
DBI("0C",5000);   

//css_code _cert_inject.part.cs

ToLog("\n\n********\n Script Complete!\n***********");   
