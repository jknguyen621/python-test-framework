//css_using Itron.Mdapi.Dev500S.Classes;

string  	CertDir     	= @"C:\RemoteDevice\Platform\RFLAN\V4\moduleTest\500sanity\security";
UInt64  	MacAddr     	= 0;

//string 		configFile 				= @"\\spade.blackhawk-lab.itron.com\IST\Software\IOT\Scripts\BPD_BringUp\RapidIntegration\NAM05\Config_Definition_Files\Dev-Mesh-500W.xml";
//string 		configTag  				= "2zBnJgUAAC";

//css_code _pib_ids.part.cs
ToLog("PibIdVer: {0}\n", PibIdVer);

/* Read Mac Address */
var mac_rsp = DBI("06 13",1000); 

if (mac_rsp != null && mac_rsp.Length > 7)
{
	Array.Reverse(mac_rsp);
	MacAddr = BitConverter.ToUInt64(mac_rsp, 0);
	ToLog("MAC = 0x{0:X16}\n", MacAddr);
}
else
{
	Utils.THROW("Unable to Read MAC address\n");
}

Action<int,int,byte[]> DLLSetPib = (id,idx,data) =>
{
	S500Utils.SetParamData(Api, id, data, idx);
};

/************************************************************************************************************
********************************************* Mac parameters ************************************************
*************************************************************************************************************/

ushort 	macSSID          	= 5556;       
/* 2 star, 1 mesh, 0 efc, start efc scan directly as a child, 6 = star only */
/* 2 star, 1 mesh, 0 efc, start efc scan directly as a child, 6 = star only, */
/*  To configure with MESH or STAR or with EFC, we can set the DLL_PIB_ID_bactCfg as given below. */
/*  DLL_PIB_ID_bactCfg       =  2;       Star Only     */
/*                           =  1;       For Mesh Only */
/*                           =  3;       star+mesh, with MESH as Preferred/First topology */
/*                           =  7;       star+mesh, with STAR as Preferred/First topology */
/*                           =  0;       EFC only = 0  */ 
byte    MacTopology       	= 1; 
var	macChannelMaskMesh	= "0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffff";
//string	macChannelMaskStar	= "0x04040404040404040404040404040404040400040404040404040404040404040404040404040404040404040404040404040404040404040404040404040404";
var	macChannelMaskStar	= "0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000004040404040404040404040404040404";
ushort  macPhyPwr			= 0;
string 		configFile 		= @"\\spade.blackhawk-lab.itron.com\IST\Software\IOT\Scripts\BPD_BringUp\NightlyEngBuilds\NAM04\Config_Definition_Files\Mesh-500G-NightlyBuild.xml";
string 		configTag  		= "2zBWly7wAC";

/* Send configuration file to the meter... */
var att           = CosemFactory.CreateICosemAttDesc(1, "0,128,96,0,1,255", 2);
var doc           = new Itron.Mdapi.Dev500S.FileFormats.EndpointConfiguration500S(configFile);			
var attWithData   = CosemFactory.CreateICosemAttWithData(att, doc.Configuration.AXDR_ICosemData);
IASetPrint(attWithData);

/* Apply configuration using the tag value */
var tagBytes = System.Text.Encoding.ASCII.GetBytes(configTag);
IASetPrint(1, "0,128,96,0,0,255", 2, String.Format("0a {0:X2} {1}", tagBytes.Length, tagBytes.ToHexStr()));

/* Set SSID in both RFLAN and App for now */
DBI("07 14" + BitConverter.GetBytes(macSSID).ToHexStr());  
DLLSetPib(DLL_PIB_ID_macSSID, 0, BitConverter.GetBytes(macSSID));

/* Set topology */
 DLLSetPib(DLL_PIB_ID_bactCfg,  0, BitConverter.GetBytes(MacTopology)); 

/* Set Power */
/* Set topology */
/* DLLSetPib(12332,  0, BitConverter.GetBytes(macPhyPwr)); */
/* DLLSetPib(12332,  1, BitConverter.GetBytes(macPhyPwr)); 8?

/* Set chan mask */
//DLLSetPib(12320,  0, BitConverter.GetBytes(macChannelMaskStar));
//DLLSetPib(12320,  1, BitConverter.GetBytes(macChannelMaskStar));

/************************************************************************************************************
************************************** More Mac PIB parameters... *******************************************
*************************************************************************************************************/
/* ToLog("Hello 0\n"); */

UInt32 efcDWListenDuration  = 27600;    /* Listen Duration for parent during discovery */
byte   efcDWNMDuration      = 10;		/* Discovery normal mode duration */
byte   efcDWDuration        = 1;		/* Duration of discovery window */
byte   efcDWRepeatInterval  = 10;		/* Repeat interval of discovery */
ushort efcFNBeaconInterval  = 300;		/* FN Periodic Beacon Repeat interval */
byte   efcNumDiscChannels   = 3;		/* Number of channels to use during discovery */
byte   efcEvalMinDur	    = 5;		/*  EFC Minimum Link Eval duration in minutes */
/* UInt32 macPrintMask = 0x1edf; */

DLLSetPib(12615, 0, BitConverter.GetBytes(efcDWListenDuration));	
DLLSetPib(12613, 0, BitConverter.GetBytes(efcDWNMDuration));		
DLLSetPib(12611, 0, BitConverter.GetBytes(efcDWDuration));			
DLLSetPib(12612, 0, BitConverter.GetBytes(efcDWRepeatInterval));	
DLLSetPib(12608, 0, BitConverter.GetBytes(efcFNBeaconInterval));	
DLLSetPib(12618, 0, "00000000000000FF".ToByteArr());
DLLSetPib(12618, 1, "00000000000000FF".ToByteArr());
DLLSetPib(12610, 0, BitConverter.GetBytes(efcNumDiscChannels));
DLLSetPib(12627, 0, BitConverter.GetBytes(efcEvalMinDur));

/* DLLSetPib(12549, 0, BitConverter.GetBytes(macPrintMask)); */
/* Save To Flash */
DBI("0C",5000);

/************************************************************************************************************
******************************************** CERT injectior ... *********************************************
*************************************************************************************************************/
/* This code performs actual key injection */
//css_code _cert_inject.part.cs


ToLog("0x{0:X8} has been successfully configured!\n", MacAddr);
ToLog("\n\n********\n Script Complete!\n***********");