/*
using Itron.Mdapi.Cosem.DLMS;
using System.Threading;

var priKey = @"a799701f347c1f1bc1012b124bcae637e1dd69551e889643a3bb088ed8c8403f";
var pubKey = @"04a296761b011ca36a2864202d241e4eb963b9999e5946ccefeee8f828525625ca4e9cf862a1724d2717ed3919941571e2c597b22281e29edcbc9efb43b3a3931a";

var keys = new KeyValuePair<int, byte[]> []
{
new KeyValuePair<int, byte[]>(1, pubKey),
new KeyValuePair<int, byte[]>(2, pubKey),
new KeyValuePair<int, byte[]>(3, pubKey),
new KeyValuePair<int, byte[]>(4, pubKey),
new KeyValuePair<int, byte[]>(5, pubKey),
new KeyValuePair<int, byte[]>(6, pubKey),
// Device / System Keys - symetric
new KeyValuePair<int, byte[]>(7, "0707070707070707070707070707070707070707070707070707070707070707".ToByteArr()), // @7
new KeyValuePair<int, byte[]>(8, "0808080808080808080808080808080808080808080808080808080808080808".ToByteArr()), // @8
new KeyValuePair<int, byte[]>(9, "0909090909090909090909090909090909090909090909090909090909090909".ToByteArr()), // @9
new KeyValuePair<int, byte[]>(10,"1010101010101010101010101010101010101010101010101010101010101010".ToByteArr()), // @10
new KeyValuePair<int, byte[]>(11, priKey),
// FWDL Related Keys
new KeyValuePair<int, byte[]>(70, priKey),
new KeyValuePair<int, byte[]>(71, pubKey),

new KeyValuePair<int, byte[]>(99, "9999999999999999999999999999999999999999999999999999999999999999".ToByteArr()), // @7
};
*/

ToLog(Color.Blue, "---------------- Injecting Keys -----------------------------\n");

Func<int, sbyte> KeyToAttId = ( Key ) =>
{
if( Key > 0 && Key < 12 )
return (sbyte)( Key + 1 );

switch( Key )
{
case 70:
case 71:
case 99:
return (sbyte)( Key + 1 );
}

return 0;
};

var listAtts = new List<sbyte>();
var listVals = new List<ICosemData>();

foreach( var key in keys )
{
var attId = KeyToAttId(key.Key);

if( attId != 0 )
{
byte[] k = null;

if( key.Value is IEnumerable<byte> )
{
k = ( key.Value as IEnumerable<byte> ).ToArray();
}
else if( key.Value is String )
{
k = ( key.Value as String ).ToByteArr();
}

if( k != null )
{
listAtts.Add(attId);
listVals.Add(CosemFactory.CreateICosemData(Itron.Mdapi.Cosem.DLMS.COSEMDataTypes.OctetString, k));
}
else
Utils.THROW("Bad key @ attribute {0}", attId);
}
}

ItronAccessReqSpec spec = new ItronAccessReqSpec(ItronAccessServiceType.Set,
new ItronAccessAttrDescList(8194, new byte[] { 0, 128, 96, 1, 8, 255 }, listAtts), listVals);

var rsp = Api.ItronAccess(spec);

ToLog(rsp.ToSmartNode(null).ToStringFull());

ToLog(Color.Blue, "------------------------------------------------------------\n");
