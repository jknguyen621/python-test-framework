var priKey = "a799701f347c1f1bc1012b124bcae637e1dd69551e889643a3bb088ed8c8403f";
var pubKey = "04a296761b011ca36a2864202d241e4eb963b9999e5946ccefeee8f828525625ca4e9cf862a1724d2717ed3919941571e2c597b22281e29edcbc9efb43b3a3931a";
var fwdlEKey = "0001020304050607000102030405060700010203040506070001020304050607";
var fwdlPubSKey = pubKey; // Signature verification key

var keys = new KeyValuePair<int, Object>[]
{
new KeyValuePair<int, Object>(1, pubKey), // @1
new KeyValuePair<int, Object>(2, pubKey), // @2
new KeyValuePair<int, Object>(3, pubKey), // @3
new KeyValuePair<int, Object>(4, pubKey), // @4
new KeyValuePair<int, Object>(5, pubKey), // @5
new KeyValuePair<int, Object>(6, pubKey), // @6

// System Keys
new KeyValuePair<int, Object>(7, "0707070707070707070707070707070707070707070707070707070707070707"), // @7
new KeyValuePair<int, Object>(8, "0808080808080808080808080808080808080808080808080808080808080808"), // @8
// Device Keyss
new KeyValuePair<int, Object>(9, "0909090909090909090909090909090909090909090909090909090909090909"), // @9
new KeyValuePair<int, Object>(10,"1010101010101010101010101010101010101010101010101010101010101010"), // @10

// // Revocation Key - Device Private Key
new KeyValuePair<int, Object>(11, priKey), // @11
new KeyValuePair<int, Object>(12, "12121212121212121212121212121212"), // @12 - seed

// FWDL Related Keys
new KeyValuePair<int, Object>(70, fwdlEKey),
new KeyValuePair<int, Object>(71, fwdlPubSKey),

// FDM Session Key
new KeyValuePair<int, Object>(99, "9999999999999999999999999999999999999999999999999999999999999999"), // @99
};



