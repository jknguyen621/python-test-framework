Action<int,int,byte[]> DLLSetPib = (id,idx,data) =>
{
	S500Utils.SetParamData(Api, id, data, idx);
};

// Func<int,int,byte[]> DLLGetPib = (id,idx) =>
// {
	// return S500Utils.GetParamData(Api, id, idx).ToByteArr();
// };
              
Func<UInt64> ReadMacAddress = () =>
{
	UInt64  addr = 0;
	
	var mac_rsp = DBI("06 13",1000); 

	if (mac_rsp != null && mac_rsp.Length > 7)
	{
		Array.Reverse(mac_rsp);
		addr = BitConverter.ToUInt64(mac_rsp, 0);
	}
	else
	{
		Utils.THROW("Unable to Read MAC address\n");
	}
	
	return addr;
};
              

			  